"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { SHORT_LEN, type Song } from "@/lib/types";
export type Mode="short"|"full";
// One shared <audio> for the whole app => never two sounds at once.
let el:HTMLAudioElement|null=null;
const audio=()=>(el??=new Audio());

export function useAudioPlayer(queue:Song[]=[]){
 const [song,setSong]=useState<Song|null>(null);
 const [mode,setMode]=useState<Mode>("full");
 const [playing,setPlaying]=useState(false);
 const [time,setTime]=useState(0);
 const [duration,setDuration]=useState(0);
 const [volume,setVolumeState]=useState(1);
 const r=useRef({song,mode,queue}); r.current={song,mode,queue};

 useEffect(()=>{
  const a=audio();
  const tu=()=>{const {song:s,mode:m}=r.current;
   if(m==="short"&&s){ if(a.currentTime>=s.golden_30_start+SHORT_LEN) a.currentTime=s.golden_30_start; setTime(a.currentTime-s.golden_30_start); }
   else setTime(a.currentTime)};
  const md=()=>setDuration(r.current.mode==="short"?SHORT_LEN:a.duration||0);
  const on=()=>setPlaying(true), off=()=>setPlaying(false);
  const end=()=>{ if(r.current.mode==="full") step(1) };
  a.addEventListener("timeupdate",tu);a.addEventListener("loadedmetadata",md);a.addEventListener("play",on);a.addEventListener("pause",off);a.addEventListener("ended",end);
  setPlaying(!a.paused);
  return()=>{a.removeEventListener("timeupdate",tu);a.removeEventListener("loadedmetadata",md);a.removeEventListener("play",on);a.removeEventListener("pause",off);a.removeEventListener("ended",end)};
  // eslint-disable-next-line react-hooks/exhaustive-deps
 },[]);

 const load=useCallback((s:Song,m:Mode)=>{
  const a=audio(); a.pause();
  const start=m==="short"?s.golden_30_start:0;
  const url=new URL(s.audio_url,location.href).href;
  if(a.src!==url) a.src=s.audio_url;
  a.currentTime=start;
  setSong(s);setMode(m);setTime(0);setDuration(m==="short"?SHORT_LEN:s.duration);
  return a.play().catch(()=>setPlaying(false));
 },[]);
 const play=useCallback(()=>audio().play().catch(()=>{}),[]);
 const pause=useCallback(()=>audio().pause(),[]);
 const toggle=useCallback(()=>{const a=audio();a.paused?a.play().catch(()=>{}):a.pause()},[]);
 const seek=useCallback((t:number)=>{const {song:s,mode:m}=r.current;audio().currentTime=m==="short"&&s?s.golden_30_start+t:t},[]);
 const setVolume=useCallback((v:number)=>{audio().volume=v;setVolumeState(v)},[]);
 const step=useCallback((d:number)=>{const {song:s,mode:m,queue:q}=r.current;if(!s||!q.length)return;
  const i=q.findIndex(x=>x.id===s.id);load(q[(i+d+q.length)%q.length],m)},[load]);
 const stop=useCallback(()=>{const a=audio();a.pause()},[]);
 return {song,mode,playing,time,duration,volume,load,play,pause,toggle,seek,setVolume,stop,next:()=>step(1),previous:()=>step(-1)};
}
