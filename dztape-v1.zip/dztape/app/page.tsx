"use client";
import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { GENRES, SHORT_LEN, type Genre, type Song } from "@/lib/types";
import { getSongs } from "@/lib/data";
import { moodBg } from "@/lib/mood";
import { useAudioPlayer } from "@/hooks/useAudioPlayer";

export default function Discover(){
 const [all,setAll]=useState<Song[]>([]);
 const [genre,setGenre]=useState<Genre>("rai_nouveau");
 const [activeId,setActiveId]=useState<string|null>(null);
 const [liked,setLiked]=useState<Record<string,boolean>>({});
 const unlocked=useRef(false); // browsers need a first tap before audio
 const touch=useRef<{x:number;y:number}|null>(null);
 const songs=useMemo(()=>all.filter(s=>s.genre===genre),[all,genre]);
 const p=useAudioPlayer(songs);
 const active=songs.find(s=>s.id===activeId)??songs[0];

 useEffect(()=>{getSongs().then(setAll)},[]);
 useEffect(()=>{setActiveId(songs[0]?.id??null);p.stop()},[genre]); // eslint-disable-line
 // play the visible card's Short Song, stop the previous
 useEffect(()=>{ if(!active) return; if(unlocked.current) p.load(active,"short"); else p.stop() },[active?.id]); // eslint-disable-line
 useEffect(()=>()=>p.stop(),[]); // eslint-disable-line

 const onTap=(s:Song)=>{ unlocked.current=true; p.song?.id===s.id&&p.mode==="short" ? p.toggle() : p.load(s,"short") };
 const swipeGenre=(d:number)=>{const i=GENRES.findIndex(g=>g.key===genre);const n=GENRES[i+d];if(n)setGenre(n.key)};

 return(
 <main className="relative h-dvh overflow-hidden"
  onTouchStart={e=>{touch.current={x:e.touches[0].clientX,y:e.touches[0].clientY}}}
  onTouchEnd={e=>{const t=touch.current;if(!t)return;const dx=e.changedTouches[0].clientX-t.x,dy=e.changedTouches[0].clientY-t.y;
   if(Math.abs(dx)>70&&Math.abs(dx)>Math.abs(dy)*1.5) swipeGenre(dx<0?1:-1)}}> {/* RTL: swipe left = next */}
  <div key={active?`${active.genre}_${active.mood}`:genre} className="bgfade fixed inset-0 -z-10" style={{background:moodBg(active?.genre??genre,active?.mood??"")}}/>
  <header className="fixed inset-x-0 top-0 z-20 px-4 pt-3 bg-gradient-to-b from-black/50 to-transparent">
   <div className="flex items-center justify-between"><h1 className="text-xl font-extrabold tracking-tight">Dz<span className="text-amber-400">Tape</span></h1><span aria-hidden>🚗</span></div>
   <nav className="mt-2 flex gap-2 overflow-x-auto pb-2 [scrollbar-width:none]">
    {GENRES.map(g=><button key={g.key} onClick={()=>setGenre(g.key)} className={`shrink-0 rounded-full px-3 py-1 text-sm ${g.key===genre?"bg-amber-400 font-semibold text-black":"bg-white/10"}`}>{g.label}</button>)}
   </nav>
  </header>
  <div className="feed">
   {songs.length===0&&<div className="card grid place-items-center text-white/70">لا توجد أغاني في هذه الفئة بعد</div>}
   {songs.map(s=><Card key={s.id} s={s} on={p.song?.id===s.id&&p.mode==="short"&&p.playing} t={p.song?.id===s.id?p.time:0}
     liked={!!liked[s.id]} onLike={()=>setLiked(l=>({...l,[s.id]:!l[s.id]}))} onTap={()=>onTap(s)} onVisible={()=>setActiveId(s.id)}/>)}
  </div>
 </main>);
}

function Card({s,on,t,liked,onLike,onTap,onVisible}:{s:Song;on:boolean;t:number;liked:boolean;onLike:()=>void;onTap:()=>void;onVisible:()=>void}){
 const ref=useRef<HTMLElement>(null);
 useEffect(()=>{const o=new IntersectionObserver(([e])=>e.isIntersecting&&onVisible(),{threshold:0.6});ref.current&&o.observe(ref.current);return()=>o.disconnect()},[]); // eslint-disable-line
 const share=()=>{const u=`${location.origin}/song/${s.id}`;navigator.share?navigator.share({title:s.title,text:s.artist,url:u}).catch(()=>{}):navigator.clipboard?.writeText(u)};
 return(
 <section ref={ref} className="card flex flex-col items-center justify-center px-6 pt-24 pb-6">
  <button onClick={onTap} aria-label={on?"إيقاف":"تشغيل"} className="relative aspect-square w-full max-w-xs overflow-hidden rounded-3xl bg-white/10 shadow-2xl">
   {s.cover_url?<img src={s.cover_url} alt="" className="h-full w-full object-cover"/>:<div className="grid h-full place-items-center text-7xl opacity-40">🎵</div>}
   <span className="absolute inset-0 grid place-items-center bg-black/20 text-6xl">{on?"⏸":"▶"}</span>
  </button>
  <div className="mt-3 h-1 w-full max-w-xs overflow-hidden rounded bg-white/20"><div className="h-full bg-amber-400" style={{width:`${(t/SHORT_LEN)*100}%`}}/></div>
  <div className="mt-4 w-full max-w-xs">
   <p className="text-sm text-white/70">{s.artist}</p>
   <h2 className="text-2xl font-extrabold">{s.title}</h2>
   <p className="text-sm text-amber-300">#{s.genre.replace("_","")} · Short Song 00:30</p>
  </div>
  <div className="mt-4 flex w-full max-w-xs gap-3 text-2xl">
   <button onClick={onLike} aria-label="إعجاب">{liked?"❤️":"🤍"}</button>
   <button onClick={onLike} aria-label="حفظ">💾</button>
   <button onClick={share} aria-label="مشاركة">🔗</button>
  </div>
  <Link href={`/song/${s.id}`} className="mt-4 w-full max-w-xs rounded-full bg-white py-3 text-center font-bold text-black">🎵 استمع للأغنية كاملة</Link>
  <p className="mt-3 text-xs text-white/50">اسحب ↑ للأغنية التالية</p>
 </section>);
}
