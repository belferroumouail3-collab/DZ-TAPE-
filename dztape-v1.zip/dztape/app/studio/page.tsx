"use client";
import { useRef, useState } from "react";
import { GENRES, SHORT_LEN, fmt, parseTime, type Genre } from "@/lib/types";
import { suggestGoldenClip } from "@/lib/golden";
import { supabase } from "@/lib/supabase";

export default function Studio(){
 const [file,setFile]=useState<File|null>(null);
 const [url,setUrl]=useState("");
 const [dur,setDur]=useState(0);
 const [start,setStart]=useState("00:00");
 const [meta,setMeta]=useState({title:"",artist:"",genre:"rai_nouveau" as Genre,mood:"night"});
 const [msg,setMsg]=useState("");
 const a=useRef<HTMLAudioElement>(null);
 const startSec=parseTime(start);

 async function pick(f:File){
  setFile(f);setUrl(URL.createObjectURL(f));setMsg("جارٍ تحليل الطاقة الصوتية…");
  try{const r=await suggestGoldenClip(f);setStart(fmt(r.start));setDur(r.duration);setMsg("")}catch{setMsg("تعذّر تحليل الملف. اختر البداية يدويًا.")}
 }
 function preview(){const el=a.current;if(!el)return;el.currentTime=startSec;el.play();setTimeout(()=>el.pause(),SHORT_LEN*1000)}
 async function save(){
  if(!file) return;
  if(!supabase) return setMsg("Supabase غير مضبوط (.env.local).");
  setMsg("جارٍ الحفظ…");
  const path=`${Date.now()}-${file.name.replace(/\W+/g,"_")}`;
  const up=await supabase.storage.from("songs").upload(path,file);
  if(up.error) return setMsg(up.error.message);
  const audio_url=supabase.storage.from("songs").getPublicUrl(path).data.publicUrl;
  const ins=await supabase.from("songs").insert({...meta,audio_url,duration:Math.round(dur),golden_30_start:startSec});
  setMsg(ins.error?ins.error.message:"تم الحفظ ✅");
 }
 const inp="w-full rounded-xl bg-white/10 px-3 py-2";
 return(
 <main className="mx-auto max-w-md space-y-3 p-5">
  <h1 className="text-2xl font-extrabold">استوديو الفنان</h1>
  <input type="file" accept="audio/mpeg,audio/*" onChange={e=>e.target.files?.[0]&&pick(e.target.files[0])} className={inp}/>
  <input className={inp} placeholder="عنوان الأغنية" value={meta.title} onChange={e=>setMeta({...meta,title:e.target.value})}/>
  <input className={inp} placeholder="اسم الفنان" value={meta.artist} onChange={e=>setMeta({...meta,artist:e.target.value})}/>
  <select className={inp} value={meta.genre} onChange={e=>setMeta({...meta,genre:e.target.value as Genre})}>{GENRES.map(g=><option key={g.key} value={g.key} className="text-black">{g.label}</option>)}</select>
  <input className={inp} placeholder="المزاج: night / party / calm…" value={meta.mood} onChange={e=>setMeta({...meta,mood:e.target.value})}/>
  {url&&<section className="space-y-2 rounded-2xl bg-white/10 p-4">
   <audio ref={a} src={url} preload="metadata" onLoadedMetadata={e=>!dur&&setDur(e.currentTarget.duration)}/>
   <h2 className="font-bold">🎯 Suggested Golden Clip</h2>
   <p dir="ltr" className="text-lg">{fmt(startSec)} → {fmt(startSec+SHORT_LEN)}</p>
   <p className="text-xs text-white/60">اقتراح مبني على الطاقة الصوتية (RMS) فقط، يمكنك تعديله.</p>
   <button onClick={preview} className="rounded-full bg-white px-4 py-2 font-semibold text-black">▶ Preview</button>
   <label className="block text-sm">البداية (mm:ss)<input dir="ltr" className={inp} value={start} onChange={e=>setStart(e.target.value)} pattern="\d{1,2}:\d{2}"/></label>
   <button onClick={save} className="w-full rounded-full bg-amber-400 py-3 font-bold text-black">Save</button>
  </section>}
  {msg&&<p role="status" className="text-sm text-amber-300">{msg}</p>}
 </main>);
}
